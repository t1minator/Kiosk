(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['templates:tabs'] = {};

})();

//# sourceMappingURL=templates_tabs.js.map
