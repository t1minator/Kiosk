(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['semantic:ui-css'] = {};

})();

//# sourceMappingURL=semantic_ui-css.js.map
