(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var BrowserPolicy = Package['browser-policy-common'].BrowserPolicy;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['browser-policy'] = {};

})();

//# sourceMappingURL=browser-policy.js.map
