(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['fabienb4:autoform-semantic-ui'] = {};

})();

//# sourceMappingURL=fabienb4_autoform-semantic-ui.js.map
